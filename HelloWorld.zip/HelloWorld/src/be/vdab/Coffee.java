package be.vdab;

public class Coffee {
    public static void main(String[] args) {

    }
}
