package be.vdab;

public class MijnLoopje {
    public static void main(String[] args) {

        int teller = 1;
        int leeftijd = 1;

        do {
            teller++;
            System.out.println(teller);

        } while (teller < leeftijd);


    }
}
