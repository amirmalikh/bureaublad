package be.vdab;

public class Array {
    public static void main(String[] args) {
     /*   int b = 5; // scalar, variable

        int[] j = {1, 2, 5, 7, 9, -6, 12};
        System.out.println(j.length);

        int index = 0; // berekend
        int getal = j[index];
        System.out.println(getal);


        for (int i = 0; i < j.length; i++) {
            System.out.println(j[i]);
            }

    */


   /*     String[] names = {"Jimmy", "Janice", "Jim", "Amy", "Kurt"};

        for (int i = 0; i < names.length; i++) {
            System.out.println(names[i]);
        }
*/
 /*       String[] mailLijst = {
                "Jimmy@gmail.com",
                "Janice@gmail.com",
                "Jim@gmail.com",
                "Amy@gmail.com",
                "Kurt@gmail.com"
        };


        for (int i = 0; i < mailLijst.length; i++) {
            System.out.println(mailLijst[i]);
        }

        for (String naam : mailLijst){
            stuuEmailNaar(naam);
        }
*/

/*
        int[] j = {1, 2, 5, 7, 9, -6, 12};


        for (int i = 0; i < j.length; i++) {

            System.out.println(j[i] *= 2);
        }
*/

/*

        int[] getallen = new int[20];     //een array met 20 beschikbare velden

        for (int i : getallen) {
            System.out.println(i);
        }
*/

        String s = null;
        System.out.println("ERVOOR");

        if (s != null) {
            s.toUpperCase();
        }
        else {
            System.out.println("Uppercase niet mogelijk");
        }

    }

}

