/*public class ArraysOefeningMatrice {
    public static void main(String[] args) {
  /*      OEFENING 4 MATRICES
                - bepaal twee matrixen adhv arrays (2d)
                - vermenigvuldig deze twee
     */
/*
  int[][] a = {
          {1, 2, 0},
          {2, 3, 4},
  };
  int[][] b = {
          {1, 2,},
          {3, 2},
          {1, 4},
            };

  int[][] c = mul (a,b);
    }
    public static int[][] mul (int[][] a, int[][] b) {
        if (a[0].length == b.length) {
            System.out.println();


        }


    }
}
*/