/*public class Random30 {

    public static void main(String[] args) {

        for (int i = 0; i<100; i++) {
        }
        int r = Random30.berekenRandomGetal(2,5);
        System.out.println(r);

        int r = Random30.berekenRandomGetal(17,48);
        System.out.println(r);

        int r = Random30.berekenRandomGetal(2,5);
        System.out.println(r);


    }

    public static int berekenRandomGetal (int min, int max) {

        int random =((int)(Math.random() * ((max - min) +1 )) + min);
        return random;
    }
}
*/