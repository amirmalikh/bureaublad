package be.vdab;

public class CheckPassFail {
    public static void main(String[] args) {

    int mark = 49;

    if (mark>=50)
        {
            System.out.println("PASS");
        } else {
            System.out.println("FAIL");
        }


    }
}

