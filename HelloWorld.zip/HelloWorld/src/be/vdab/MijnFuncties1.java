package be.vdab;

public class MijnFuncties1 {
    public static void main(String[] args) {

        String mySting = "Dit is een lange tekst, die hier alleen maar staat om oefeningen op te maken";

        String [] splits = mySting.split(" ");

        System.out.println(mySting.toUpperCase());
        System.out.println(splits[11]);


    }


}
