package be.vdab.beehive;

public class Insect extends Object {
    void eat() {

    }

    void crawl() {

    }

    void poo() {

    }
}
