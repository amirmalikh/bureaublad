package be.vdab.beehive;

public class Flower {
    int nectar;
    String color;
    String name;

    public Flower(int nectar, String color, String name) {
        this.nectar = nectar;
        this.color = color;
        this.name = name;
    }
}
