package be.vdab.beehive;

public class Queen extends Bee {


    public Larva layLarva () {
        return new Larva();
    }
}
