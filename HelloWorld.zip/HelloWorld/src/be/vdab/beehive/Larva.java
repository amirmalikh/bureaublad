package be.vdab.beehive;

public class Larva {
    int size;

}
