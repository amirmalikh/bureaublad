package be.vdab;

public class Sterretjes {

    public static void main(String[] args) {
        char ster = '*';

        for (int teller = 1 ; teller <= 6;teller++){



        }


    }
}
