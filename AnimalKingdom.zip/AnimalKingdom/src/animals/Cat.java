package animals;

public class Cat extends Animal {


    protected int lives = 9;

    public int getLives() {
        return lives;
    }


    public void scratch(){
        System.out.println("scratch");
    }

    public Cat(){
    }

    public Cat(String name){
        super(name, 80, 8,3);
        System.out.println("Created new cat with name " + name + " and " + lives + " lives.");

    }
    @Override
    public void sound(){
        System.out.println("Cat " + name + " is making a sound: Miauw");
    }

}
