package animals;

public class Lion extends Cat {


    private int power;

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public Lion(){
    }

    public Lion (String name, int power) {
        super(name);
        System.out.println("Created lion with name " + name + ", " + lives + " lives and " + power + " power.");
        this.power= power;
        this.lives = getLives();
    }

    @Override
    public void sound() {
        System.out.println("Lion " + name + " is making a sound: Roaar");
    }

    public void rule () {
        if(power > 10) {
            System.out.println("Rule with blessing from the gods");
        } else {
            if(Math.random() > 0.5) {
                System.out.println("Gets kicked off the trone and the guillotine is waiting");
            }

        }
    }

}
