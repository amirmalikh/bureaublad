package animals;

public class AnimalMain {
    public static void main(String[] args) {

        Cat tom = new Cat("Tom");
        tom.scratch();
        tom.sound();

        System.out.println();

        Lion mufassa = new Lion("Mufassa",100);
        mufassa.sound();
        mufassa.rule();

        System.out.println();

        Bird tweety = new Bird ("Tweety");
        tweety.sound();
        tweety.fly();

        System.out.println();

        Dog jacky = new Dog("Jacky",new String[] {"Roll", "Sit", "Stay", "Bark"});
        jacky.sound();
        jacky.bite(tweety);





    }
}
