package animals;

public class Rabbit extends Animal {

    public void sound(){
        System.out.println("Rabbit " + name + " is making a sound: Miet");
    }
}
