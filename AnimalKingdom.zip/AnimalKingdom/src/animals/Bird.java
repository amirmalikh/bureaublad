package animals;

public class Bird extends Animal {

    protected int gust = attack;

    public Bird () {
    }

    public Bird (String name){
        super(name,50,10,2);
        System.out.println("Created new bird with name " + name + "." );
    }

    public void fly(){
        System.out.println("Bird " + name + " is flying around");
    }

    @Override
    public void sound() {
        System.out.println("Bird with name " + name + " is making a sound: Tsjierp ");
    }


}
