package animals;

import java.util.Arrays;
import java.util.Random;

public class Dog extends Animal {

    protected String[] tricks;
    protected int bitingPower = attack;

    public String[] getTricks() {
        return tricks;
    }

    public void setTricks(String[] tricks) {
        this.tricks = tricks;
    }

    public Dog() {
    }

    public Dog(String name, String[] tricks) {
        super(name, 100, 25,5);
        System.out.println("Created dog with name " + name + ", that knows the following tricks: "
                //+ Arrays.toString(tricks)
        );
        this.name = name;
        for (String trick : tricks) {
            System.out.println("- " + trick);
        }

        this.tricks = tricks;
    }

    public void bite(Animal target) {
        int defenderDamage = Math.max(0, (int) (Math.random() * this.bitingPower * 1.5) - target.armor);
        System.out.println(
                "Attacker " + getName() + " attacks defender " + target.getName() +
                        " dealing " + defenderDamage + " amount of damage causing defender to "
        );
        target.hitpoints -= defenderDamage;
        if (target.isDead()) {
            System.out.println(" Target dead");
        } else {
            if (new Random().nextBoolean()) {
                int attackerDamage = Math.max(0, (int) ((Math.random() * target.attack * 0.5) - this.armor));
                this.hitpoints -= attackerDamage;
                System.out.print("respond with a counter attack dealing " + attackerDamage + " amount of damage causing attacker to ");
                if (this.isDead()) {
                    System.out.println("die");
                } else {
                    System.out.println("survive");
                }
            } else {
                System.out.println("survive");
            }
        }

    }



    @Override
    public void sound() {
        System.out.println("Dog " + name + " is making a sound: Woof");
    }

}