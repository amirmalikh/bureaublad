package animals;

public abstract class Animal {
   protected String name;
   protected int hitpoints;
   protected int armor;
   protected int attack;


   public Animal() {
   }

    public Animal(String name, int hitpoints, int attack, int armor){
       System.out.println("Created animal with name " + name + " and " + hitpoints + " hitpoints" );
       this.name = name;
       this.hitpoints = 50;
       this.attack = 10;
       this.armor = 1;

   }

   public abstract void sound();



    public int getHitpoints() {
        return hitpoints;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public boolean isDead() {
        return hitpoints <= 0;
    }


}

